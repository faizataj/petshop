const sql = require ("mysql");

const db = sql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "petz"
})
db.connect();
module.exports = db;