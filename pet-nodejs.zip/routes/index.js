const indexModule = require ("../model")({})
const jwt = require('jsonwebtoken');


module.exports = function (routers, expressApp){

// -----------------------------------login----------------------------------------
routers.post('/login', indexModule.login);


function authenticateToken(req, res, next){
    
     const authHeader = req.headers['authorization']
     console.log(authHeader);
     const token = authHeader && authHeader.split(' ')[1]

     if (token == null)
     return res.sendStatus(401)

     jwt.verify(token, process.env.ACCESS_TOKEN_SECRET, (err, user)=>{
        if(err)
        return res.sendStatus(403)

        req.user = user
        next()
     })
}



    routers.post('/registration', indexModule.registration);
    

// -----------------------------------Category----------------------------------------
    routers.get("/getCategory", indexModule.getCategory);

    routers.get ("/getCategoryById", indexModule.getCategoryById);

    routers.post("/postCategory", indexModule.postCategory);

    routers.put("/updateCategory", indexModule.updateCategory);

    routers.delete("/deleteCategory", indexModule.deleteCategory);

// -----------------------------------pet products----------------------------------------

    routers.get("/getProducts", indexModule.getProducts);

    routers.get("/getProductById", indexModule.getProductById);

    routers.post("/postProduct", indexModule.postProduct);

    routers.put("/updateProduct", indexModule.updateProduct);

    routers.delete("/deleteProduct", indexModule.deleteProduct);


// -----------------------pet order-------------------------------------------------------

    routers.post("/addToCart",authenticateToken,indexModule.addToCart);

    routers.post("/deleteFromCart",indexModule.deleteFromCart);

    routers.post('/deleteallcartitem', indexModule.deleteallcartitem);

	routers.post('/cartitems', indexModule.cartitems);

    routers.post('/cart/check',indexModule.productavailcheck);

    routers.get("/getOrder", indexModule.getOrder);

    routers.post("/shippingAddress", indexModule.shippingaddress);

	



    

    routers.get("/getOrderById", indexModule.getOrderById);

    routers.post("/postOrder", indexModule.postOrder);

    routers.put("/updateOrder", indexModule.updateOrder);

    routers.delete("/deleteOrder", indexModule.deleteOrder);

    return routers;
}